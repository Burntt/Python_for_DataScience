import numpy as np 
import pandas as pd

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn import preprocessing

from experiments.base.transformer import BaseTransformer

class Transformer_2_1(BaseTransformer):
    def __init__(self):
        return None
    def fit_transform(self, X):
        return X
